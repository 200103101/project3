from django.contrib import admin
from .models import task,Book,test,sport,Emp
admin.site.register(task)
admin.site.register(Book)
admin.site.register(test)
admin.site.register(sport)
admin.site.register(Emp)